<?php

namespace devavi\leveltwo\Blog\Exceptions;

class UserNotFoundException extends AppException
{

}