<?php

namespace devavi\leveltwo\Blog\Exceptions;

class ArgumentsException extends AppException
{

}