<?php

namespace devavi\leveltwo\Blog\Exceptions;

class LikeAlreadyExists extends AppException
{
}
