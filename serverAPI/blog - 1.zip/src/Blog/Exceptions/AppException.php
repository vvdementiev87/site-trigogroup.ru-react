<?php

namespace devavi\leveltwo\Blog\Exceptions;

class AppException extends \Exception
{

}