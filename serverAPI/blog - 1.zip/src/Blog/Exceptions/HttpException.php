<?php

namespace devavi\leveltwo\Blog\Exceptions;

class HttpException extends AppException
{

}