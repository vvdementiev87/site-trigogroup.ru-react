<?php

namespace devavi\leveltwo\Blog\Exceptions;

class AuthTokensRepositoryException extends AppException
{
}
