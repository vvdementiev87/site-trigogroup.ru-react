<?php

namespace devavi\leveltwo\Blog\Exceptions;

class AuthTokenNotFoundException extends AppException
{
}
