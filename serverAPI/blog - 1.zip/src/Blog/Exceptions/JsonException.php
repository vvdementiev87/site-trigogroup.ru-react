<?php

namespace devavi\leveltwo\Blog\Exceptions;

class JsonException extends AppException
{

}