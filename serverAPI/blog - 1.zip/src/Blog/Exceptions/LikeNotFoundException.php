<?php

namespace devavi\leveltwo\Blog\Exceptions;

class LikeNotFoundException extends AppException
{
}
