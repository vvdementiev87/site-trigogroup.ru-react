<?php

namespace devavi\leveltwo\Blog\Exceptions;

class AuthException extends AppException
{
}
