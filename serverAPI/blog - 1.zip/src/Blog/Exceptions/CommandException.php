<?php

namespace devavi\leveltwo\Blog\Exceptions;

class CommandException extends AppException
{

}