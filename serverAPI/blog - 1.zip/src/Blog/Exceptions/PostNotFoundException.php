<?php

namespace devavi\leveltwo\Blog\Exceptions;

class PostNotFoundException extends AppException
{

}