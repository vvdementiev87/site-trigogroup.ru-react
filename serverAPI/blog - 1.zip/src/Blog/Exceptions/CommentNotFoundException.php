<?php

namespace devavi\leveltwo\Blog\Exceptions;

class CommentNotFoundException extends AppException
{

}