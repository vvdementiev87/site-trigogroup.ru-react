<?php

namespace devavi\leveltwo\Blog\Exceptions;

class InvalidArgumentException extends AppException
{

}