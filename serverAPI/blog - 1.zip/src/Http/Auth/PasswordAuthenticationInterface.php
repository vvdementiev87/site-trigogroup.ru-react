<?php

namespace devavi\leveltwo\Http\Auth;

interface PasswordAuthenticationInterface extends AuthenticationInterface
{
}
