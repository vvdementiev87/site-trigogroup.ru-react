<?php

namespace devavi\leveltwo\Http\Auth;

interface TokenAuthenticationInterface extends AuthenticationInterface
{
}
