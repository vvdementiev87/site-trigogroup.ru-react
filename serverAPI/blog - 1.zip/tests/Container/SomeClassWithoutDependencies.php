<?php

namespace devavi\leveltwo\UnitTests\Container;

class SomeClassWithoutDependencies
{
}
